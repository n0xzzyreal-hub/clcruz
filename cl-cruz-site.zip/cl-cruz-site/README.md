# CL Cruz Serralheria — catálogo automático (Mercado Livre)

Site estático (`index.html`) + 3 funções serverless (`api/`). As funções leem os anúncios **da própria conta da loja** com o token do vendedor. O token fica só no servidor. O catálogo vem em cache de 10 minutos.

## Por que é preciso autorizar a conta
A busca pública do Mercado Livre (`/sites/MLB/search`) responde 403 sem credenciais. Listar anúncios de uma conta exige o token do próprio vendedor. O `seller_id` vem da autorização, nada é digitado ou inventado.

## Passo a passo (hospedagem na Vercel)
1. **Criar o app** no DevCenter do Mercado Livre (developers.mercadolivre.com.br). Em "URL de redirecionamento", use exatamente `https://SEU-DOMINIO/api/callback`. Habilite leitura e `offline_access`. Anote o App ID e a Secret Key.
2. **Subir a pasta** na Vercel (importando do GitHub ou com `vercel deploy`).
3. **Criar um Upstash Redis** pela aba Storage/Marketplace da Vercel. Ele guarda o token (o refresh token é de uso único e muda a cada renovação).
4. **Variáveis de ambiente** no projeto:
   - `ML_CLIENT_ID` = App ID
   - `ML_CLIENT_SECRET` = Secret Key
   - `ML_REDIRECT_URI` = `https://SEU-DOMINIO/api/callback`
   - `ADMIN_KEY` = uma senha longa que você inventar
   - `UPSTASH_REDIS_REST_URL` e `UPSTASH_REDIS_REST_TOKEN` (ou `KV_REST_API_URL` e `KV_REST_API_TOKEN`, que a Vercel cria sozinha)
5. **Fazer novo deploy**, depois o **dono da loja** abre `https://SEU-DOMINIO/api/conectar?key=SUA_ADMIN_KEY`, logado na conta **principal** do Mercado Livre, e clica em autorizar. Contas de colaborador/operador não conseguem autorizar.
6. Abra o site. Para conferir, `https://SEU-DOMINIO/api/catalogo` deve devolver um JSON com os produtos.

## Limites e cuidados
- Até 1.000 anúncios ativos (para mais, é preciso trocar a listagem por `search_type=scan`).
- A consulta de itens usa `/items/bulk`, que substituiu `/items?ids=`.
- Nunca coloque `ML_CLIENT_SECRET` nem tokens no `index.html`.
- Se o site mostrar "não foi conectada", refaça o passo 5.

## Status dos testes
Feitos neste ambiente: sintaxe dos arquivos e execução do `catalogo.js` com respostas simuladas. **Não** testado contra a API real, o que só é possível depois da autorização do passo 5.
