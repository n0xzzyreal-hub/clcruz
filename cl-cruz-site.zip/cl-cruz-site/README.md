# CL Cruz Serralheria — página com botão para a loja

Página única (`index.html`). O botão “Ver loja no Mercado Livre” abre a loja.

1. O link da loja já está em `const LOJA` no `index.html`. Para trocar, edite esse endereço.
2. Publique o arquivo em qualquer hospedagem de sites simples (Netlify, Vercel, Cloudflare Pages ou GitHub Pages).

A versão anterior, com catálogo automático e API do Mercado Livre, está guardada na pasta `cl-cruz-site-catalogo-backup`.
