const crypto = require("crypto");
// Abra uma vez, logado na conta principal da loja: /api/conectar?key=SUA_ADMIN_KEY
module.exports = (req, res) => {
  const key = new URL(req.url, "http://x").searchParams.get("key");
  if (!process.env.ADMIN_KEY || key !== process.env.ADMIN_KEY) {
    res.statusCode = 401; res.setHeader("Content-Type", "text/plain; charset=utf-8"); return res.end("Chave inválida.");
  }
  const state = crypto.randomBytes(16).toString("hex");
  res.setHeader("Set-Cookie", `ml_state=${state}; HttpOnly; Secure; SameSite=Lax; Path=/api; Max-Age=600`);
  const q = new URLSearchParams({ response_type: "code", client_id: process.env.ML_CLIENT_ID, redirect_uri: process.env.ML_REDIRECT_URI, state });
  res.statusCode = 302;
  res.setHeader("Location", "https://auth.mercadolivre.com.br/authorization?" + q);
  res.end();
};
