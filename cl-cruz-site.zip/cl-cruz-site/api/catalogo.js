const { API, getToken } = require("./_ml");

const get = async (path, token) => {
  const r = await fetch(API + path, { headers: { Authorization: "Bearer " + token } });
  if (!r.ok) throw new Error(`ml_${r.status}:${path.split("?")[0]}`);
  return r.json();
};
const lote = async (arr, n, fn) => {
  const out = [];
  for (let i = 0; i < arr.length; i += n) out.push(...(await Promise.all(arr.slice(i, i + n).map(fn))));
  return out;
};

module.exports = async (req, res) => {
  const send = (code, body, cache) => {
    res.statusCode = code;
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.setHeader("Cache-Control", cache || "no-store");
    res.end(JSON.stringify(body));
  };
  try {
    const t = await getToken();
    const ids = [];
    for (let off = 0; off < 1000; off += 100) {
      const j = await get(`/users/${t.user_id}/items/search?status=active&limit=100&offset=${off}`, t.access_token);
      ids.push(...j.results);
      if (off + 100 >= j.paging.total) break;
    }
    const chunks = [];
    for (let i = 0; i < ids.length; i += 20) chunks.push(ids.slice(i, i + 20).join(","));
    const respostas = await lote(chunks, 5, (c) => get(`/items/bulk?ids=${c}`, t.access_token));
    const itens = [];
    for (const r of respostas) {
      for (const row of Array.isArray(r) ? r : r.results || r.items || []) {
        const b = row.body || row;
        if ((row.code || 200) === 200 && b.status === "active") itens.push(b);
      }
    }
    const produtos = itens.map((b) => ({
      id: b.id, titulo: b.title, preco: b.price, moeda: b.currency_id,
      foto: (b.pictures && b.pictures[0] && (b.pictures[0].secure_url || b.pictures[0].url)) || (b.thumbnail || "").replace("http://", "https://"),
      link: b.permalink, categoria: b.category_id, estoque: b.available_quantity, condicao: b.condition,
    }));
    const contagem = {};
    produtos.forEach((p) => (contagem[p.categoria] = (contagem[p.categoria] || 0) + 1));
    const nomes = await lote(Object.keys(contagem), 10, (id) => get(`/categories/${id}`, t.access_token).then((c) => ({ id, nome: c.name })).catch(() => ({ id, nome: id })));
    const categorias = nomes.map((c) => ({ ...c, total: contagem[c.id] })).sort((a, b) => b.total - a.total);
    send(200, { atualizado: new Date().toISOString(), produtos, categorias }, "s-maxage=600, stale-while-revalidate=3600");
  } catch (e) {
    if (e.code === "nao_conectado") return send(503, { erro: "nao_conectado" });
    send(502, { erro: "falha_api", detalhe: String(e.message) });
  }
};
