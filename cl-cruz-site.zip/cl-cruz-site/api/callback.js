const { tokenForm, kvSet } = require("./_ml");
module.exports = async (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  const p = new URL(req.url, "http://x").searchParams;
  const c = (req.headers.cookie || "").match(/ml_state=([a-f0-9]+)/);
  if (!p.get("code") || !c || c[1] !== p.get("state")) {
    res.statusCode = 400; return res.end("<p>Autorização inválida ou expirada. Recomece por /api/conectar.</p>");
  }
  try {
    const t = await tokenForm({ grant_type: "authorization_code", code: p.get("code"), redirect_uri: process.env.ML_REDIRECT_URI });
    await kvSet("ml_tokens", t);
    res.end(`<p>Loja conectada (vendedor ${Number(t.user_id)}). Pode fechar esta página e abrir o site.</p>`);
  } catch (e) {
    res.statusCode = 500; res.end("<p>Não foi possível conectar: " + String(e.message).replace(/[<>&]/g, "") + "</p>");
  }
};
