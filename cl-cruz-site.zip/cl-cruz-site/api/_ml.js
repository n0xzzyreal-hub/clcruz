const API = "https://api.mercadolibre.com";
const KV_URL = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
const KV_TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;

async function kvGet(k) {
  const r = await fetch(`${KV_URL}/get/${k}`, { headers: { Authorization: `Bearer ${KV_TOKEN}` } });
  const j = await r.json();
  return j.result ? JSON.parse(j.result) : null;
}
async function kvSet(k, v) {
  const r = await fetch(`${KV_URL}/set/${k}`, { method: "POST", headers: { Authorization: `Bearer ${KV_TOKEN}` }, body: JSON.stringify(v) });
  if (!r.ok) throw new Error("kv_set_" + r.status);
}
async function tokenForm(params) {
  const r = await fetch(`${API}/oauth/token`, {
    method: "POST",
    headers: { accept: "application/json", "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ client_id: process.env.ML_CLIENT_ID, client_secret: process.env.ML_CLIENT_SECRET, ...params }),
  });
  const j = await r.json();
  if (!r.ok) throw new Error(`oauth_${r.status}: ${j.message || j.error || ""}`);
  return { access_token: j.access_token, refresh_token: j.refresh_token, user_id: j.user_id, expires_at: Date.now() + (j.expires_in - 300) * 1000 };
}
// O refresh token é de uso único: cada renovação grava o novo par no armazenamento.
async function getToken() {
  const t = await kvGet("ml_tokens");
  if (!t) { const e = new Error("nao_conectado"); e.code = "nao_conectado"; throw e; }
  if (Date.now() < t.expires_at) return t;
  const n = await tokenForm({ grant_type: "refresh_token", refresh_token: t.refresh_token });
  n.user_id = n.user_id || t.user_id;
  await kvSet("ml_tokens", n);
  return n;
}
module.exports = { API, tokenForm, kvSet, getToken };
